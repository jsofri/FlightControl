# PlaneControl
An academic project for understanding GUI and MVVM architecture by making a WPF app
